// show active link
// const currentLocation = location.href
// const userLinks = document.querySelectorAll('.navigate-link')
// const productList = document.querySelector('.content-list')

// function setActive(linkArray) {
//     linkArray.forEach(link => {
//         if (currentLocation.toLowerCase().includes(link.href.toLowerCase().split('/').slice(-2)[0])) {
//             link.style.fontWeight = 'bold'
//         }
//         else return false
//     });
// }
// setActive(userLinks)
